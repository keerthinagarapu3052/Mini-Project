-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2022 at 04:05 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `water`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(30) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `email`, `password`) VALUES
('paparao', 'paparao@gmail.com', 'paparao');

-- --------------------------------------------------------

--
-- Table structure for table `cnfrm_orders`
--

CREATE TABLE `cnfrm_orders` (
  `product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_by` varchar(30) NOT NULL,
  `delivery_address` varchar(150) NOT NULL,
  `delivery_mode` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date` date DEFAULT NULL,
  `quantity` int(20) DEFAULT NULL,
  `p_total` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cnfrm_orders`
--

INSERT INTO `cnfrm_orders` (`product_id`, `order_id`, `order_by`, `delivery_address`, `delivery_mode`, `status`, `date`, `quantity`, `p_total`) VALUES
(2, 260, 'pavan@gmail.com', 'sdfgh', 'Online Payment', 'Delivered', '2022-04-26', 1, 50),
(3, 261, 'pavan@gmail.com', 'sdfgh', 'Online Payment', 'Delivered', '2022-04-26', 1, 100),
(2, 264, 'rajasrisr74@gmail.com', 'qwertyu', 'Online Payment', 'Cancelled', '2022-04-16', 1, 50),
(1, 265, 'rajasrisr74@gmail.com', 'qwertyu', 'Online Payment', 'Delivered', '2022-04-16', 1, 30),
(3, 266, 'sai123@gmail.com', 'sdfgh', 'Online Payment', 'Cancelled', '2022-04-15', 1, 100),
(1, 268, 'sai123@gmail.com', 'asdfghj', 'Online Payment', 'Cancelled', '2022-04-16', 6, 180),
(2, 270, 'sai123@gmail.com', 'awertyjk', 'Online Payment', 'Out for Delivery', '2022-04-15', 6, 300),
(2, 278, 'rajasrisr74@gmail.com', 'dfgnrvfrbr', 'Online Payment', 'Out for Delivery', '2022-04-20', 1, 50),
(3, 279, 'rajasrisr74@gmail.com', 'dfgnrvfrbr', 'Online Payment', 'Out for Delivery', '2022-04-20', 524, 52400),
(3, 282, 'srinu@gmail.com', 'rvr', 'Online Payment', 'Out for Delivery', '2022-04-14', 1, 100),
(3, 293, 'pavan@gmail.com', 'ponnur', 'cash on delivery', 'Out for Delivery', '2022-05-05', 1, 100),
(3, 296, 'keerthianji3052@gmail.com', 'jig', 'cash on delivery', 'Out for Delivery', '2022-05-16', 1, 100);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `fname`, `lname`, `email`, `comment`) VALUES
(1, 'sai', 'ganesh', 'rajasrisr74@gmail.com', 'This is simply awesome!!.. keep going guys.');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(50) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(80) NOT NULL,
  `phnnum` bigint(11) NOT NULL,
  `address` varchar(150) NOT NULL,
  `password` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `phnnum`, `address`, `password`) VALUES
(2, 'pavan', 'pavan@gmail.com', 7995932384, 'ponnur', '123456'),
(5, 'keerthi', 'keerthianji3052@gmail.com', 9676554526, 'jig', 'Daddy@1234'),
(6, 'sai', 'sai123@gmail.com', 8688142384, 'wertyui', 'ssssssss'),
(7, 'chanukya', 'chanukyakongara@gmail.com', 9966615855, 'vjhbkjb', 'chanukya'),
(9, 'ganesh', 'rajasrisr74@gmail.com', 5335356696, 'dfgnrvfrbr', '123456'),
(10, 'srinu', 'srinu@gmail.com', 45495494, 'tr7ty8u', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_by` varchar(30) NOT NULL,
  `delivery_address` varchar(150) NOT NULL,
  `delivery_mode` varchar(20) NOT NULL,
  `date` datetime NOT NULL,
  `quantity` int(10) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`product_id`, `order_id`, `order_by`, `delivery_address`, `delivery_mode`, `date`, `quantity`, `total`) VALUES
(1, 286, 'srinu@gmail.com', '', '', '0000-00-00 00:00:00', 1, 30);

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `expire_date` date NOT NULL,
  `delivery_time` time NOT NULL,
  `user` varchar(255) NOT NULL,
  `user_contact` varchar(255) NOT NULL,
  `user_address` text NOT NULL,
  `payment_stat` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `prod_id`, `quantity`, `total`, `duration`, `start_date`, `expire_date`, `delivery_time`, `user`, `user_contact`, `user_address`, `payment_stat`) VALUES
(63, 2, 1, 50, '1 year', '2022-04-15', '2023-04-10', '15:45:00', 'pavan@gmail.com', '123456765432', 'jewhkfg', 'succesfull'),
(64, 1, 1, 30, '1 year', '2022-04-15', '2023-04-10', '15:45:00', 'pavan@gmail.com', '123456765432', 'jewhkfg', 'succesfull'),
(67, 2, 1, 50, '1 month', '2022-04-24', '2022-05-24', '14:55:00', 'rajasrisr74@gmail.com', '9676554526', 'qwert', 'cash on delivery'),
(68, 3, 1, 100, '1 month', '2022-04-24', '2022-05-24', '14:55:00', 'rajasrisr74@gmail.com', '9676554526', 'qwert', 'cash on delivery'),
(74, 1, 1, 30, '6 months', '2022-05-24', '2022-11-20', '09:04:00', 'keerthianji3052@gmail.com', '8688142384', 'kpd', 'succesfull'),
(75, 2, 1, 50, '6 months', '2022-05-24', '2022-11-20', '09:04:00', 'keerthianji3052@gmail.com', '8688142384', 'kpd', 'succesfull');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `name` varchar(30) NOT NULL,
  `email` varchar(25) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`name`, `email`, `comment`) VALUES
('Bisleri', 'bisleri@gmail.com', 'we want to supply bottles and colloborate with you');

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`id`, `name`, `code`, `image`, `price`) VALUES
(1, 'Normal water', 'NM', './product-images/can6.jpg', 30.00),
(2, 'cool water', 'CW', './product-images/cool2.jpg', 50.00),
(3, 'water bottles (10 per pack)', 'WB', './product-images/water7.jpg', 100.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `cnfrm_orders`
--
ALTER TABLE `cnfrm_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD UNIQUE KEY `code_2` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=297;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
