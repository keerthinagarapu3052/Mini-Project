<div class="header">
           <div style="font-family:lucida; margin-left:10px;"> Aqua suppliers 
            <div class="inner2">
                <a href="#pic" class="btn btn-warning btn-md" role="button">Register/Login</a>
                <a href="about.php" class="btn btn-warning btn-md" role="button">About us</a>
                <a href="contact.php" class="btn btn-warning btn-md" role="button">Contact Us</a>
            </div>
</div>
</div>