<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="header">
            Aqua suppliers
            <div class="inner">
                <a href="logout.php" id='logout'><i class='fa fa-power-off ' style="font-size:26px;color:white"> Logout</i></a>
            </div>
</div>