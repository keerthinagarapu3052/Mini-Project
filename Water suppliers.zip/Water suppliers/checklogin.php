<?php
if(!isset($_SESSION['email'])){
echo '<script type="text/javascript">window.location="index.php"; </script>';
}
?>